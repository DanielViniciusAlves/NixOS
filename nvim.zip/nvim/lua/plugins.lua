return {
    -- Transparência
    {
        "xiyaowong/transparent.nvim",
        opts = {
            extra_groups = { "NormalFloat" },
        },
    },

    -- Oil (file manager)
    {
        "stevearc/oil.nvim",
        opts = {},
    },

    -- Comment.nvim
    {
        "numToStr/Comment.nvim",
        opts = {
            opleader = {
                line = "<leader>c",
                block = "gb",
            },
        },
        keys = {
            { "<leader>c", mode = { "n", "v" }, desc = "Comment line/block" },
        },
    },

    -- Marks.nvim
    {
        "chentoast/marks.nvim",
        opts = {
            mappings = {
                set_next = "m;",
                delete_line = "m'",
            },
        },
    },

    -- GitSigns
    {
        "lewis6991/gitsigns.nvim",
        opts = {},
    },

    -- Undotree
    {
        "mbbill/undotree",
        keys = {
            { "<leader>u", vim.cmd.UndotreeToggle, desc = "Toggle Undotree" },
        },
    },

    -- Mini Icons
    { "echasnovski/mini.icons" },

    -- Copilot
    { "github/copilot.vim" },

    -- Tmux navigation
    {
        'alexghergh/nvim-tmux-navigation',
        config = function()
            require 'nvim-tmux-navigation'.setup {
                disable_when_zoomed = true, -- defaults to false
                keybindings = {
                    left = "<C-h>",
                    down = "<C-j>",
                    up = "<C-k>",
                    right = "<C-l>",
                    last_active = "<C-\\>",
                    next = "<C-Space>",
                }
            }
        end
    },

    -- Markdown Preview
    {
        "iamcco/markdown-preview.nvim",
        build = "cd app && npm install",
        ft = { "markdown" },
        keys = {
            { "<leader>mp", "<cmd>MarkdownPreviewToggle<cr>", desc = "Toggle Markdown Preview" },
        },
    },
}
