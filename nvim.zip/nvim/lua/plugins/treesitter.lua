return {
  "nvim-treesitter/nvim-treesitter",
  build = ":TSUpdate",
  event = { "BufReadPost", "BufNewFile" },
  opts = {
    ensure_installed = {}, -- Adicione linguagens aqui, ex: { "lua", "python", "javascript" }
    auto_install = false,
    highlight = { enable = true },
    indent = { enable = true },
  },
}
