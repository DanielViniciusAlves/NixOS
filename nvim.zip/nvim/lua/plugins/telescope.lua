return {
  "nvim-telescope/telescope.nvim",
  dependencies = {
    "nvim-lua/plenary.nvim",
    "nvim-telescope/telescope-ui-select.nvim",
  },
  config = function()
    local actions = require("telescope.actions")

    require("telescope").setup({
      defaults = {
        mappings = {
          i = {
            ["<C-j>"] = actions.move_selection_next,
            ["<C-k>"] = actions.move_selection_previous,
          },
        },
      },
      extensions = {
        ["ui-select"] = {
          require("telescope.themes").get_dropdown({})
        },
      },
    })

    require("telescope").load_extension("ui-select")

    local builtin = require("telescope.builtin")
    local opts = { noremap = true, silent = true }

    vim.keymap.set("n", "<leader>pf", builtin.find_files, opts)
    vim.keymap.set("n", "<leader>pg", builtin.git_files, opts)
    vim.keymap.set("n", "<leader>ps", builtin.live_grep, opts)
    vim.keymap.set("n", "<leader>po", builtin.oldfiles, opts)
    vim.keymap.set("n", "<leader>ca", function()
      vim.lsp.buf.code_action()
    end, vim.tbl_extend("force", opts, { desc = "Code Action" }))
  end,
}


