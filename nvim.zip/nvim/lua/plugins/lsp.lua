return {
    { "hrsh7th/cmp-nvim-lsp" },
    { "folke/neodev.nvim" },
    {
        "williamboman/mason.nvim",
        config = function()
            require("mason").setup()
        end
    },

    {
        "mason-org/mason-lspconfig.nvim",
        opts = {
            ensure_installed = {
                "lua_ls",
                "jdtls",
                "pylsp",
            },
            handlers = {}
        },
        dependencies = {
            { "mason-org/mason.nvim", opts = {} },
            "neovim/nvim-lspconfig",
        },
    },

    {
        "neovim/nvim-lspconfig",
        config = function()
            local lspconfig = require('lspconfig')

            local on_attach = function(client, buffer)
                local bufopts = { noremap = true, silent = true, buffer = buffer }

                vim.keymap.set("n", "gd", "<cmd>Telescope lsp_definitions<cr>", bufopts)
                vim.keymap.set("n", "gr", "<cmd>Telescope lsp_references<cr>", bufopts)
                vim.keymap.set("n", "gD", vim.lsp.buf.declaration, bufopts)
                vim.keymap.set("n", "gI", "<cmd>Telescope lsp_implementations<cr>", bufopts)
                vim.keymap.set("n", "gt", "<cmd>Telescope lsp_type_definitions<cr>", bufopts)

                local format = function()
                    vim.lsp.buf.format({ bufnr = buffer })
                end

                if client.supports_method("textDocument/formatting") then
                    vim.keymap.set("n", "<leader>f", format, bufopts)
                end
            end

            local capabilities = vim.lsp.protocol.make_client_capabilities()
            capabilities = require('cmp_nvim_lsp').default_capabilities(capabilities)

            require('neodev').setup()

            -- Add default setup for every lsp not specified
            local servers = require("mason-lspconfig").get_installed_servers()
            for _, server in ipairs(servers) do
                if server == "lua_ls" then
                    lspconfig.lua_ls.setup({
                        on_attach = on_attach,
                        capabilities = capabilities,
                        settings = {
                            Lua = {
                                runtime = {
                                    version = "LuaJIT",
                                },
                                diagnostics = {
                                    globals = { "vim", "it", "describe", "before_each", "after_each" },
                                },
                                workspace = {
                                    library = vim.api.nvim_get_runtime_file("", true),
                                    checkThirdParty = false,
                                },
                                telemetry = {
                                    enable = false,
                                },
                                completion = {
                                    callSnippet = "Replace",
                                },
                            },
                        },
                    })
                else
                    lspconfig[server].setup({
                        on_attach = on_attach,
                        capabilities = capabilities,
                    })
                end
            end
        end
    }
}
