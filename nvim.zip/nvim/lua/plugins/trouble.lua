return {
  "folke/trouble.nvim",
  cmd = "Trouble",
  keys = {
    { "<leader>dT", "<CMD>Trouble diagnostics toggle focus=true<CR>", desc = "Diagnostics (Trouble, all buffers)" },
    { "<leader>dt", "<CMD>Trouble diagnostics toggle filter.buf=0 focus=true<CR>", desc = "Diagnostics (Trouble, current buffer)" },
    { "<leader>ds", "<CMD>Trouble symbols toggle focus=true<CR>", desc = "Symbols (Trouble)" },
  },
  opts = {
    keys = {
      N = "prev",
      n = "next",
      ["<cr>"] = "jump_close",
      h = "help",
    },
  },
}

