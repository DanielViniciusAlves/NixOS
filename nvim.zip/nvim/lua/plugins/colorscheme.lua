return {
  {
    "ellisonleao/gruvbox.nvim",
    priority = 1000,
    opts = {
      transparent_mode = true, -- ativa transparência interna do gruvbox
    },
    config = function(_, opts)
      require("gruvbox").setup(opts)

      -- aplica o tema
      vim.cmd.colorscheme("gruvbox")

      -- garante fundo transparente para outros grupos que não respeitam o modo transparente
      vim.cmd([[
        highlight Normal guibg=none ctermbg=none
        highlight NonText guibg=none ctermbg=none
        highlight StatusLine guibg=none ctermbg=none
      ]])
    end,
  },
}

