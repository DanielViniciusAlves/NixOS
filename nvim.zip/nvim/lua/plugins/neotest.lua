return {
  { "nvim-neotest/neotest-plenary" },
  {"nvim-neotest/neotest",
  keys = {
    { "<leader>t", function() require("neotest").run.run() end, desc = "Run nearest test" },
    { "<leader>T", function() require("neotest").run.run(vim.fn.expand("%")) end, desc = "Run tests in current file" },
    { "<leader>tp", function() require("neotest").run.stop() end, desc = "Stop running tests" },
    { "<leader>tq", function() require("neotest").output_panel.toggle() end, desc = "Toggle output panel" },
  },
  opts = function()
    if vim.bo.filetype == "java" then
      return {} -- não configura para Java
    end

    return {
      adapters = {
        -- require("neotest-java")({
        --   junit_jar = nil,
        --   incremental_build = true,
        --   dap = { justMyCode = false },
        -- }),
      },
    }
  end,
}
}
